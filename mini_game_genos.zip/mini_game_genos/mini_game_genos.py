import pygame

pygame.init()

#######################Basic#################################

class Genos:
    def __init__(self,x,y,direction,k_left,k_rigth,k_punch,k_jump,k_blast,image,blast_img):
        self.x=x
        self.y=y
        self.direction = direction
        self.k_left,self.k_rigth,self.k_punch,self.k_jump,self.k_blast = k_left,k_rigth,k_punch,k_jump,k_blast
        self.rigth,self.left = False,False
        self.rigth_frame_count,self.left_frame_count,self.taking_damage_count = 5,5,10
        self.rigth_frame,self.left_frame=0,0
        self.velocity_y,self.blastball_active = 0,[]
        self.is_jumping,self.taking_damage,self.taking_ball  = False,False,False
        self.getting_img(image, blast_img)
        self.life,self.damage_to_take = 100,0
    def getting_img(self,image,blast_img):
        self.get_img_basic(image)
        self.get_img_run(image)
        self.get_img_punch(image)
        self.get_img_jump(image)
        self.get_img_damaged(image)
        self.get_img_blast(image)
        self.get_img_blastball(blast_img)
    def get_img_basic(self,image):
        rect_basic = pygame.Rect(0, 380, 37, 55)
        image_basic = image.subsurface(rect_basic)
        # Découper l'image
        self.image_basic_rigth = image.subsurface(rect_basic)
        self.image_basic_rigth.set_colorkey((51,49,50))
        self.image_basic_rigth = [self.image_basic_rigth]
        # Inverser l'image verticalement
        self.image_basic_left = pygame.transform.flip(image_basic, True, False)
        self.image_basic_left.set_colorkey((51,49,50))
        self.image_basic_left = [self.image_basic_left]
    def get_img_run(self,image):
        self.run_param = [[[0,905,42,55],[40,60]],[[60, 910, 35, 55],[40,60]],[[110, 910, 40, 55],[45,60]]]
        self.run_rigth_img,self.run_left_img = [],[]
        for i in range(len(self.run_param)):
            rect = pygame.Rect(self.run_param[i][0])
            img = image.subsurface(rect)
            img = pygame.transform.scale(img,(self.run_param[i][1]))
            img.set_colorkey((51,49,50))
            self.run_rigth_img.append(img)
            img_inv = pygame.transform.flip(img, True, False)
            img_inv.set_colorkey((51,49,50))
            self.run_left_img.append(img_inv)
    def get_img_punch(self,image):
           self.punch_param = [[[0,1164,38,55],[38,55]],[[47,1164,43,55],[45,55]],[[103,1164,47,55],[48,56]],[[160,1164,38,55],[38,55]]]
           self.punch_rigth_img,self.punch_left_img = [],[]
           self.punch_left,self.punch_rigth = False,False
           self.punch_rigth_frame_count,self.punch_left_frame_count = 2,2
           self.punch_rigth_frame,self.punch_left_frame=0,0
           for i in range(len(self.punch_param)):
               rect = pygame.Rect(self.punch_param[i][0])
               img = image.subsurface(rect)
               img = pygame.transform.scale(img,(self.punch_param[i][1]))
               img.set_colorkey((51,49,50))
               self.punch_rigth_img.append(img)
               img_inv = pygame.transform.flip(img, True, False)
               img_inv.set_colorkey((51,49,50))
               self.punch_left_img.append(img_inv)
    def get_img_jump(self,image):
            self.jump_param =   [[[45,988,42,56],[42,56]],[[55,1078,42,56],[45,56]]] 
            self.jump_rigth_img,self.jump_left_img = [],[]
            self.jump_frame,self.jump_frame_count = 10,10
            for i in range(len(self.jump_param)):
                rect = pygame.Rect(self.jump_param[i][0])
                img = image.subsurface(rect)
                img = pygame.transform.scale(img,(self.jump_param[i][1]))
                img.set_colorkey((51,49,50))
                self.jump_rigth_img.append(img)
                img_inv = pygame.transform.flip(img, True, False)
                img_inv.set_colorkey((51,49,50))
                self.jump_left_img.append(img_inv)    
    def get_img_damaged(self,image):
        self.damaged_param =    [[[40, 2730, 40, 60],[45,60]],[[77, 2730, 40, 60],[45,62]]]
        self.damaged_rigth_img,self.damaged_left_img = [],[]
        self.damaged_frame,self.damaged_frame_count = 0,7
        for i in range(len(self.damaged_param)):
            rect = pygame.Rect(self.damaged_param[i][0])
            img = image.subsurface(rect)
            img = pygame.transform.scale(img,(self.damaged_param[i][1]))
            img.set_colorkey((51,49,50))
            self.damaged_rigth_img.append(img)
            img_inv = pygame.transform.flip(img, True, False)
            img_inv.set_colorkey((51,49,50))
            self.damaged_left_img.append(img_inv) 
    def get_img_blast(self,image):
        self.blast_param = [[[0, 2555, 30, 60],[35,60]],[[48, 2558, 34, 60],[40,64]],[[100, 2558, 40, 60],[45,65]],[[160, 2558, 42, 60],[45,65]],[[218, 2558, 45, 60],[45,65]],[[275, 2558, 46, 60],[45,65]],[[336, 2558, 46, 60],[45,65]],[[405, 2558, 46, 60],[50,65]],[[460, 2558, 46, 60],[50,65]],[[520, 2558, 46, 60],[45,65]],[[575, 2558, 46, 60],[45,65]],[[630, 2558, 46, 60],[45,65]]]
        self.blast_rigth_img,self.blast_left_img = [],[]
        self.blast_frame,self.blast_frame_count = 0,7
        self.blast_b = False,False
        for i in range(len(self.blast_param)):
            rect = pygame.Rect(self.blast_param[i][0])
            img = image.subsurface(rect)
            img = pygame.transform.scale(img,(self.blast_param[i][1]))
            img.set_colorkey((51,49,50))
            self.blast_rigth_img.append(img)
            img_inv = pygame.transform.flip(img, True, False)
            img_inv.set_colorkey((51,49,50))
            self.blast_left_img.append(img_inv) 
    def get_img_blastball(self,blast_img):
        self.blasballs = []
        for i in range(6):
            rect = pygame.Rect((30+i)*16,0,16,16)
            img = blast_img.subsurface(rect)
            img = pygame.transform.scale(img,(32,32))
            img.set_colorkey((51,49,50))
            self.blasballs.append(img)
            
    def move_right(self):
        if not self.taking_damage:
            self.x+=2
            self.rigth,self.direction = True,"rigth"
            self.rigth_frame_count -=1
            if self.rigth_frame_count ==0:
                self.rigth_frame +=1
                self.rigth_frame_count = 5
                if self.rigth_frame >= len(self.run_param):self.rigth_frame=0
    def move_left(self):
        if not self.taking_damage:
            self.x-=2
            self.left,self.direction= True,"left"
            self.left_frame_count -=1
            if self.left_frame_count ==0:
                self.left_frame +=1
                self.left_frame_count = 5
                if self.left_frame >= len(self.run_param):self.left_frame=0
    def punch_r(self):
        if not self.taking_damage:
            self.punch_rigth = True
            self.punch_rigth_frame_count -=1
            if self.punch_rigth_frame_count ==0:
                self.punch_rigth_frame +=1
                self.punch_rigth_frame_count = 2
                if self.punch_rigth_frame >= len(self.punch_param):self.punch_rigth_frame=0
        self.punch_rect = pygame.Rect(self.x+35,self.y,20,50)
    def punch_l(self):
        if not self.taking_damage:
            self.punch_left = True
            self.punch_left_frame_count -=1
            if self.punch_left_frame_count ==0:
                self.punch_left_frame +=1
                self.punch_left_frame_count = 2
                if self.punch_left_frame >= len(self.punch_param):self.punch_left_frame=0
        self.punch_rect = pygame.Rect(self.x-7,self.y,20,50)
    def blast(self):
        if not self.taking_damage:
            self.blast_b = True
            self.blast_frame_count -=1
            if self.blast_frame_count ==0:
                self.blast_frame +=1
                self.blast_frame_count = 7
                if self.blast_frame == 8 and self.blast_frame_count == 7 :self.blastball_active.append([0,[self.x+10,self.y+8],10,self.direction])
                if self.blast_frame >= len(self.blast_param):
                    self.blast_frame=0
    def key_pressed(self,key,jump_strength):
        result = self.image_basic_rigth,0
        if key[self.k_jump] and not self.is_jumping and self.damage_to_take ==0:
            self.velocity_y = jump_strength
            self.is_jumping = True
        elif key[self.k_blast] and self.damage_to_take ==0:
            if self.direction == "rigth":
                self.blast()
                result= self.blast_rigth_img,self.blast_frame
            else : 
                self.blast()
                result= self.blast_left_img,self.blast_frame
        elif key[self.k_punch] and self.damage_to_take ==0:
            if self.direction == "rigth":
                self.punch_r()
                result= self.punch_rigth_img,self.punch_rigth_frame
            else : 
                self.punch_l()
                result= self.punch_left_img,self.punch_left_frame
        elif key[self.k_rigth] and self.damage_to_take ==0:
            self.move_right()
            result= self.run_rigth_img,self.rigth_frame
        elif key[self.k_left] and self.damage_to_take ==0:
            self.move_left()
            result= self.run_left_img,self.left_frame
        else:
            if self.direction == "rigth":
                result= self.image_basic_rigth,0
            else : result= self.image_basic_left,0
        if self.is_jumping:
            if self.direction == "rigth": result =self.jump_rigth_img,self.jump_frame
            else : result =self.jump_left_img,self.jump_frame
            self.jump_frame_count -=1
            if self.jump_frame_count ==0:
                self.jump_frame +=1
          
        return result
    def actu_rect(self):
        self.rect = pygame.Rect(self.x,self.y,35,50)
    def actu_frame(self):
        if not self.rigth : 
            self.rigth_frame = 0
            self.rigth_frame_count = 5
        if not self.left : 
            self.left_frame = 0
            self.left_frame_count = 5
        if not self.punch_rigth:
            self.punch_rigth_frame = 0
            self.punch_rigth_frame_count = 5
        if not self.punch_left:
            self.punch_left_frame = 0
            self.punch_left_frame_count = 5
        if not self.taking_damage:
            self.damaged_frame_count =5
            self.damaged_frame = 0
        self.rigth,self.left,self.punch_rigth,self.punch_left = False,False,False,False
        self.actu_rect()
    
    def gravity(self,gravity,ground_level,ground_x,largeur_fenetre):
        self.velocity_y+= gravity
        self.y += self.velocity_y

        if self.y >= ground_level and self.x >= ground_x and self.x <= largeur_fenetre-25:
            self.y = ground_level
            self.is_jumping = False
            self.velocity_y = 0
            self.jump_frame,self.jump_frame_count = 0,10
    def back_damage(self,direction):
        if direction == "rigth": self.x-=1
        else:self.x+=1
        self.damage_to_take-=1
    def take_damage(self,direction,power):
        self.taking_damage = True
        if direction == "rigth": 
            blit = [self.damaged_rigth_img,self.damaged_frame]
        else : blit = [self.damaged_left_img,self.damaged_frame]
        self.damaged_frame_count -=1
        if  self.damaged_frame_count ==0:
            self.damaged_frame_count = 7
            self.damaged_frame += 1
            if self.damaged_frame ==2:
                self.damaged_frame=0
        self.damage_to_take += power
        return blit
    def take_ball(self,direction):
        if  direction == "rigth": blit = [self.damaged_rigth_img,0]
        else : blit = [self.damaged_left_img,0]
        self.taking_damage_count-=1
        if  self.taking_damage_count == 0:
            self.taking_damage_count = 10
            self.taking_ball  = False
        return blit
    def hit_img_pos(self):
        if self.direction == "left":
            return [self.x,self.y]
        else:
            return [self.x-5,self.y]
    def opponent_pos(self,opponent_x):
        if opponent_x > self.x:
            return "rigth"
        else: 
            return "left"
    def move_ball(self,fenetre,largeur_fenetre):
        for ball in self.blastball_active:
            fenetre.blit(self.blasballs[ball[0]],(ball[1]))
            if ball[3] == "rigth": ball[1][0]+=2
            else : ball[1][0]-=2
            ball[2] -=1
            if ball[2]==0:
                ball[2]=10
                ball[0]+=1
                if ball[0] ==6:
                    ball[0]=0
        self.blastball_active = [[int_val, sub_list, another_int,direction] for int_val, sub_list, another_int,direction in self.blastball_active if sub_list[0] < largeur_fenetre and sub_list[0] > -20]
    def destroy_ball(self,ball):
        self.blastball_active.remove(ball)
    
        

class Fighting_game:
    def __init__(self):
        # Créer la fenêtre
        self.largeur_fenetre, self.hauteur_fenetre = 400, 300
        self.fenetre = pygame.display.set_mode((self.largeur_fenetre, self.hauteur_fenetre))
        pygame.display.set_caption("1 v 1 ")
        self.ecriture = pygame.font.Font(None, 50)
        self.mini_ecriture = pygame.font.Font(None, 25)
        # Charger l'image
        self.image = pygame.image.load("genos_sprite.png")
        self.plateforme =pygame.image.load("plateforme.jpg")
        self.plateforme = pygame.transform.scale(self.plateforme,(400,300))
        self.impact1 =pygame.image.load("Effect_Impact_1_001.png")
        self.impact1 = pygame.transform.scale(self.impact1,(50,50))
        self.fire_img = pygame.image.load("Fire Effect.png")
        self.ground_level,self.ground_x = 149,15
        self.genos1 = Genos(20,self.ground_level,"rigth",pygame.K_q,pygame.K_d,pygame.K_e,pygame.K_z,pygame.K_a,self.image,self.fire_img)
        self.genos2 = Genos(350,self.ground_level,"left",pygame.K_k,pygame.K_m,pygame.K_p,pygame.K_o,pygame.K_i,self.image,self.fire_img)
        self.gravity,self.jump_strength = 1,-12
        self.clock = pygame.time.Clock()
        self.fps = 60
        self.running,self.game = True,True
    def end_game(self):
        if self.genos1.y > self.hauteur_fenetre : 
            self.game = False
            self.winner = 2
        elif self.genos2.y > self.hauteur_fenetre : 
            self.game = False
            self.winner = 1
    def play(self):    
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
             # Récupérer l'état des touches
            self.fenetre.fill((240,240, 240))
            self.fenetre.blit(self.plateforme,(0,0))
            if self.game:
                self.touches = pygame.key.get_pressed()
                # obtenir affichage
                self.blit1 = self.genos1.key_pressed(self.touches,self.jump_strength)
                self.blit2 = self.genos2.key_pressed(self.touches,self.jump_strength)
                # Appliquer la gravité
                self.genos1.gravity(self.gravity,self.ground_level,self.ground_x,self.largeur_fenetre)
                self.genos2.gravity(self.gravity,self.ground_level,self.ground_x,self.largeur_fenetre)
                
                if self.genos1.punch_left or self.genos1.punch_rigth:
                    if self.genos1.punch_rect.colliderect(self.genos2.rect):
                        self.blit2 = self.genos2.take_damage(self.genos2.opponent_pos(self.genos1.x),2)
                        self.genos2.life -= 0.2
                    else : self.genos2.taking_damage = False
                else : self.genos2.taking_damage = False
            
                if self.genos2.punch_left or self.genos2.punch_rigth:
                    if self.genos2.punch_rect.colliderect(self.genos1.rect):
                        self.blit1=self.genos1.take_damage(self.genos1.opponent_pos(self.genos2.x),2)
                        self.genos1.life -= 0.2
                    else : self.genos1.taking_damage = False
                else : self.genos1.taking_damage = False
                # afficher
                for ball in self.genos1.blastball_active :
                    rect= pygame.Rect(ball[1][0],ball[1][1],32,32)
                    if rect.colliderect(self.genos2.rect): 
                        self.genos1.destroy_ball(ball)
                        self.blit2 = self.genos2.take_damage(self.genos2.opponent_pos(self.genos1.x),(200 -int(self.genos2.life) *2)/3)
                        self.genos2.taking_ball = True
                        self.genos2.life -= 10
                for ball in self.genos2.blastball_active :
                    rect= pygame.Rect(ball[1][0],ball[1][1],32,32)
                    if rect.colliderect(self.genos1.rect): 
                        self.genos2.destroy_ball(ball)
                        self.blit2 = self.genos1.take_damage(self.genos1.opponent_pos(self.genos2.x),(200 -int(self.genos1.life) *2)/3)
                        self.genos1.taking_ball = True
                        self.genos1.life -= 10
                
                if self.genos2.taking_ball : self.blit2 = self.genos2.take_ball(self.genos2.opponent_pos(self.genos1.x))
                if self.genos1.taking_ball : self.blit1 = self.genos1.take_ball(self.genos1.opponent_pos(self.genos2.x))
                
                if self.genos1.damage_to_take>=1:self.genos1.back_damage(self.genos1.opponent_pos(self.genos2.x))
                else: self.genos1.damage_to_take =0
                if self.genos2.damage_to_take>=1:self.genos2.back_damage(self.genos2.opponent_pos(self.genos1.x))
                else: self.genos2.damage_to_take =0
                self.fenetre.blit(self.blit1[0][self.blit1[1]],(self.genos1.x,self.genos1.y))
                self.fenetre.blit(self.blit2[0][self.blit2[1]],(self.genos2.x,self.genos2.y))
                
                self.genos1.move_ball(self.fenetre,self.largeur_fenetre)
                self.genos2.move_ball(self.fenetre,self.largeur_fenetre)
                
  
                self.genos1.actu_frame()
                self.genos2.actu_frame()
                
                if self.genos2.taking_damage: self.fenetre.blit(self.impact1,self.genos2.hit_img_pos())
                if self.genos1.taking_damage: self.fenetre.blit(self.impact1,self.genos1.hit_img_pos())
                genos1_life_ecr = self.mini_ecriture.render(str(int(self.genos1.life)),True,(255,255,255))
                genos2_life_ecr = self.mini_ecriture.render(str(int(self.genos2.life)),True,(255,255,255))
                self.fenetre.blit(genos1_life_ecr,((self.largeur_fenetre/15)*3,5))
                self.fenetre.blit(genos2_life_ecr,((self.largeur_fenetre/15)*11,5))
                pygame.draw.rect(self.fenetre,(0,255,0),[-2,24,201,12])
                pygame.draw.rect(self.fenetre,(255,0,0),[-2,25,int(self.genos1.life) *2,10])
                pygame.draw.rect(self.fenetre,(0,255,0),[201,24,201,12])
                pygame.draw.rect(self.fenetre,(255,0,0),[202 + (200 -int(self.genos2.life) *2),25,int(self.genos2.life) *2,10])
                self.end_game()  
            # Rafraîchir l'écran
            else : 
                self.txt  = self.ecriture.render(f"Le joueur {self.winner} à gagner", True, (255,0,0))
                self.fenetre.blit(self.txt,(self.largeur_fenetre/15,25))
            pygame.display.flip()
            self.clock.tick(self.fps)
            
        pygame.quit()

# Boucle principale
fighting_game = Fighting_game()
fighting_game.play()